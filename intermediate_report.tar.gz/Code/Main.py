import os
import sys
import pandas as pd
from yaml import load, dump
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper


#-----------------------------------------------------------------------------------------------------------------------------------------#

#Fix data irregularities like, city is missing in many results. Fill default values or fetch these values from some 3rd Party API.
def fixIrregularities(frame):
    return frame

#-----------------------------------------------------------------------------------------------------------------------------------------#

#fetch other vital information like Weather, Pitch condition, Altitude, Latitude, Longitude, etc. Use some 3rd Party API.
def fetchInfo(frame):
    return frame

#-----------------------------------------------------------------------------------------------------------------------------------------#  

#Transform data from yaml format to CSV format
def dataTransformer(dir, csvFile):
    df = pd.DataFrame()

    for fn in os.listdir(dir):
        fn = os.path.join(dir, fn)
        #print(fn)
        if os.path.isdir(fn):
            print("What is a folder doing in there ?")
            exit(1)
            continue

        f = open(fn, 'r')
        data = load(f, Loader=Loader)
        
        info = data['info']
        
        if not 'city' in info:
            print("City not found in file %s" % (fn))
            continue

        if len(info['dates']) > 1:
            print("Multiple dates in file %s" % (fn))
            continue

        if info['toss']['decision'] == 'bat':
            first_to_bat = info['teams'].index(info['toss']['winner'])
        else:
            first_to_bat = (info['teams'].index(info['toss']['winner']) + 1) % 2
                        
        if 'winner' in info['outcome']:
            win_or_draw = 0  #0 = win
        elif info['outcome']['result'] == 'tie':
            win_or_draw = 1 # 1 = tie
        else:
            win_or_draw = 2 # 2 = no result
                          
        this_row = pd.DataFrame({'Year'  : [info['dates'][0].year],
                                 'Month' : [info['dates'][0].month], 
                                 'Day' : [info['dates'][0].day], 
                                 'City' : [info['city']], 
                                 'Venue' : [info['venue']], 
                                 'FirstTeam' : [info['teams'][0]], 
                                 'SecondTeam' : [info['teams'][1]], 
                                 'FirstToBat' : [first_to_bat], 
                                 'Result' : [win_or_draw],
                                 'Winner' : [info['teams'].index(info['outcome']['winner'])] if win_or_draw == 0 else [0]
                               })
        df = pd.concat([df, this_row])

    df.to_csv(csvFile, index=False)
    print("Output written to training_data.csv")
    return df

#-----------------------------------------------------------------------------------------------------------------------------------------#

#Train the system using gathered data
def train(csvFile):
    data = pd.read_csv(csvFile)
    print(data.describe())

    #train_cols = data.columns[0:6].join(data.columns[9])

    #logit = sm.Logit(data['Winner'], data[train_cols])
    #model = logit.fit()

    model = "something"
    return model

#-----------------------------------------------------------------------------------------------------------------------------------------#

#Predict the match result using trained system
def predictResult(model, frame):
    
    #result = model.predict(frame)
    result = "Team 0 wins"
    return result

#-----------------------------------------------------------------------------------------------------------------------------------------#

#Main
if len(sys.argv) < 3:
    print("please provide parameters")
    exit(1)

df = dataTransformer(sys.argv[1], sys.argv[2])
df = fetchInfo(df)
df = fixIrregularities(df)
model = train(sys.argv[2])
result = predictResult(model,sys.argv[3])
print(result)



