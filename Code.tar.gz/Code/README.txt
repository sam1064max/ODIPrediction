Cricket game result prediction

Samiran Roy 153050091
Sushant Shambharkar 153050081
Ganesh Bhambarkar 153050072
Surendra Singh Rao 153050069


To run:

python final_svc.py

It will print the predicted result of the game for each game in the test_case.csv file.

The supported values for City, Venue, FirstTeam and SecondTeam are limited by the training data.
You can check for examples in the training data.